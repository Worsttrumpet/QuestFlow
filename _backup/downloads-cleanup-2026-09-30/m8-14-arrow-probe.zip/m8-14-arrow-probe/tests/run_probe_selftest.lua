-- run_probe_selftest.lua (lua5.1, from this tests/ directory). Probe logic only; proves nothing about Forever.
local passed, failed = 0, 0
local function check(c, n) if c then passed = passed + 1; print("[OK]   " .. n) else failed = failed + 1; print("[FAIL] " .. n) end end
local function widget()
	local w = { __scripts = {}, __text = "", rot = nil, points = {} }
	return setmetatable(w, { __index = function(_, k)
		if k == "SetScript" then return function(self, n, f) self.__scripts[n] = f end end
		if k == "SetText" then return function(self, t) self.__text = t end end
		if k == "CreateTexture" then return function() local t = widget(); t.SetRotation = function(s, r) s.rot = r end
			t.SetTexture = function(s, p) s.path = p; return true end; t.GetTexture = function(s) return s.path end; return t end end
		if k == "CreateFontString" then return function() return widget() end end
		if k == "GetPoint" then return function() return "TOP", nil, "TOP", 12, -150 end end
		if k == "IsShown" then return function() return true end end
		return function() end
	end })
end
local function run(opts)
	local chat, frames = {}, {}
	_G.DEFAULT_CHAT_FRAME = { AddMessage = function(_, m) table.insert(chat, m) end }
	_G.CreateFrame = function() local f = widget(); table.insert(frames, f); return f end
	_G.UIParent, _G.Minimap = widget(), widget()
	_G.SlashCmdList = {}
	_G.ForeverProbeM814DB = nil
	local facing = 1.0
	_G.GetPlayerFacing = (not opts.noFacing) and function() return facing end or nil
	_G.GetCursorPosition = function() return 0, 0 end
	local ns = {}
	assert(loadfile("../addon/ForeverProbeM814/ForeverProbeM814.lua"))("ForeverProbeM814", ns)
	_G.ForeverProbeM814DB = opts.saved   -- SavedVariables restored after file load (M8.12)
	frames[1].__scripts.OnEvent(frames[1], "ADDON_LOADED", "ForeverProbeM814")
	SlashCmdList.FOREVERPROBEM814("")
	local win = ns._selftest.getWindow()
	for _ = 1, 3 do facing = facing + 0.5; win.__scripts.OnUpdate(win, 0.2) end
	win.__scripts.OnDragStart(win); win.__scripts.OnDragStop(win)
	win.__scripts.OnMouseUp(win, "LeftButton")
	SlashCmdList.FOREVERPROBEM814("report")
	return ns, chat, win
end
local ns, chat, win = run({})
local r = ns._selftest.results
check(ForeverProbeM814DB.sessions[1].results == r, "session attached to the restored SavedVariables table")
check(r.facing.samples == 3 and math.abs(r.facing.max - 2.5) < 1e-9 and math.abs(r.facing.min - 1.5) < 1e-9, "facing sampled and range recorded")
check(r.textures.A.set_ok and r.textures.A.get_texture and r.textures.A.rotation_ok, "texture load and rotation recorded")
check(win.tex[1].rot == 2.5, "textures rotated by facing")
check(r.drag.started == 1 and r.drag.stopped == 1 and r.drag.last_point.x == 12, "drag start/stop and saved point recorded")
check(r.drag.clicks.LeftButton == 1, "left click recorded separately from drag")
local sawReport = false for _, m in ipairs(chat) do if m:find("GetPlayerFacing: ok") then sawReport = true end end
check(sawReport, "report summarises results")
local ns2, chat2 = run({ noFacing = true, saved = { sessions = { { probe_version = "earlier" } } } })
check(ForeverProbeM814DB.sessions[1].probe_version == "earlier" and #ForeverProbeM814DB.sessions == 2, "earlier sessions kept")
check(ForeverProbeM814DB.sessions[2].apis.GetPlayerFacing == "absent", "absent GetPlayerFacing recorded, no crash")
check(ns2._selftest.results.textures.A.rotation_ok == nil, "no rotation attempted without facing")
print(string.format("\n%d passed, %d failed", passed, failed))
os.exit(failed == 0 and 0 or 1)
