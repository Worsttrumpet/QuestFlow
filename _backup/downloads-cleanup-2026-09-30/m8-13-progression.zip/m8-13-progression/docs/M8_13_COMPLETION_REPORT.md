# M8.13 Completion Report: Progression Controller Implementation

**Status: implemented; 81/81 stub tests pass; real-client validation PENDING.**
ForeverQuestGuide **`m8-guide-addon-0.7`** (from 0.6). Semi-automatic progression: the addon detects and latches
a satisfied step and shows it as complete, but moves only on the player's confirmation.

## 1. Implementation completed

### Files

| File | Change |
|---|---|
| `ProgressionEval.lua` | **New.** Pure evaluators for ACCEPT, TURN_IN, OBJECTIVE (quest-level), TRAVEL (same-continent distance), plus a read-only state reader. Never raises; errors become UNDETECTABLE |
| `Progression.lua` | **New.** Controller: route pointer by route/step ID, states `NOT_READY` / `WAITING` / `UNDETECTABLE` / `SATISFIED` (latched) / `ROUTE_COMPLETE` + `PAUSED` overlay; Next (confirm/manual/finish), Previous, Skip, Reset Step, Undo, Pause; persistence; thin event adapters |
| `UI.lua` | Route-pane section moved verbatim into `buildRoutePanel(frame)`; status line; NEXT label shows `CONFIRM ->` / `FINISH ->` / `Route Complete`; Skip / Reset Step / Undo / Pause row; Previous/Next routed through the controller; route pane +50 px taller for the new rows |
| `Preferences.lua` | Defaults re-applied at `ADDON_LOADED` via `ApplyDefaults()`; incorrect SavedVariables-timing comment corrected (M8.12) |
| `Core.lua` | Version `m8-guide-addon-0.7`; calls `ApplyDefaults()` at `ADDON_LOADED`; `/fguide progress pause\|resume\|skip\|reset\|undo\|status`; load message updated |
| `ForeverQuestGuide.toc` | Version, notes, load order (`ProgressionEval.lua`, `Progression.lua` before `UI.lua`) |
| `Data.lua`, `RouteData.lua`, `MapPin.lua`, `MinimapButton.lua`, `WelcomePopup.lua` | Unchanged |

### `build()` refactor

| Function | Upvalues |
|---|---|
| `build()` before (v0.6) | **56** / 60 |
| `build()` after refactor | **35** |
| `build()` after all M8.13 changes | **37** |
| new `buildRoutePanel()` | 28 |
| highest in any addon function | 37 |

Behaviour preservation was proven with a recording harness (`tests/ui_trace_harness.lua`): v0.6 and the
refactored build produced **byte-identical traces** of a scripted UI session (1,595 widget calls, 138 widgets,
both Show on Map paths), before any progression code was added.

### Architecture

- **Adapters** (bottom of `Progression.lua`) turn events into signals: `QUEST_ACCEPTED`, `QUEST_TURNED_IN`,
  `UNIT_QUEST_LOG_CHANGED` (unit `"player"` only), `QUEST_LOG_UPDATE` (re-check hint), `ZONE_CHANGED*` and a 0.5 s
  position tick that runs **only** while the current step is a TRAVEL step with a destination.
  `QUEST_REMOVED`, `QUEST_WATCH_UPDATE`, navigation, waypoint, and super-track events are not registered.
- **Evaluators** decide satisfaction for the current step only.
- **Controller** evaluates nothing before `PLAYER_LOGIN`; latches `SATISFIED`; the single place automatic
  advancement would go is marked `AUTO-ADVANCE HOOK`.
- **UI** renders controller state and forwards clicks.

### Startup and persistence

- `ADDON_LOADED`: read `ForeverQuestGuideDB.progress` (`routeID`, `stepID`, `complete`, `paused`, `skipped`).
  Missing route → first route, step 1. Step not in route → step 1. No saved progress → step 1.
- `PLAYER_LOGIN`: reconcile the current step against game state; chat reports route, step, and how the position
  was chosen.
- Before `ADDON_LOADED` the controller holds step 1 of the first route, so the pointer is never empty.
- Latches and detection results are never persisted; they are recomputed at login.

## 2. Unit/stub-test results

`tests/run_progression_tests.lua` (lua5.1): **81 passed, 0 failed.** Coverage against the brief:

| Required test | Covered |
|---|---|
| ACCEPT / TURN_IN / OBJECTIVE satisfaction | Yes (signal and reconciliation paths; `QUEST_REMOVED` never counts) |
| TRAVEL same-map / same-continent distance | Yes (real read layer against stubbed map APIs) |
| TRAVEL missing destination / cross-continent → undetectable | Yes (also position unavailable, unknown kind) |
| Latching; turn-in reset cannot undo | Yes |
| Manual advancement; skip; reset; undo; pause | Yes (controller API and real UI buttons) |
| Startup: no saved / valid saved / stale saved (step and route) | Yes; plus "events before `PLAYER_LOGIN` ignored" and "position sane before `ADDON_LOADED`" |
| Route completion | Yes (finish, skip-to-finish, undo, previous from complete) |
| Regressions: Previous, both Show on Map paths, `/fguide progress status`, preferences defaulting | Yes |
| Read-only (no quest-changing call) | Yes |

Issues found and fixed during testing:

1. A UI helper was placed before the button factory it uses; Lua would have resolved it as an undefined global at
   runtime. Moved; a bytecode scan of all changed files confirms only real WoW/Lua globals are referenced.
2. Undo after Previous popped a stale entry. Previous (and route selection) now clear undo history, so Undo only
   reverses the advance just made.
3. The controller had no route until `ADDON_LOADED`; it now starts at step 1 of the first route.

The project's own existing UI self-test (in the repository) was not available in this environment; run it locally
as well.

## 3. Real-client validation

**PENDING** — procedure in `M8_13_GUIDE.md`. The test route's quests (907, 959) are not on the character, so the
real-client run exercises waiting/undetectable states and every control, but cannot show a step becoming
satisfied without questing. The satisfied path is covered by stub tests and rests on signals already verified in
M8.7–M8.9.

## 4. Known limitations

- **Logout persistence is not guaranteed** (M8.0 §2; M8.12 saved only via `/reload`).
- **Progress is account-wide**: all characters share one saved position (no `SavedVariablesPerCharacter`, per brief).
- **TRAVEL requires route destination data.** The only TRAVEL step (`s2`) has none, so it shows as
  "can't detect this step (no destination in route data)".
- **TRAVEL radius is a provisional design value** (20 yd, `ProgressionEval.lua`), not a measurement; the schema has
  no radius field.
- **Cross-continent TRAVEL is not automatically detected.**
- **OBJECTIVE uses quest-level completion**, not `objective_index`; a step for one objective of a multi-objective
  quest is satisfied only when the whole quest is.
- **Automatic advancement is intentionally not implemented.**
- **Game navigation/waypoint/super-track state is never used as a progression signal.**
- Only steps on the current pointer are evaluated; events for later steps are not remembered (re-checked from state
  on arrival where the state supports it — ACCEPT, TURN_IN via the completed flag, OBJECTIVE; not TRAVEL).

## 5. Deferred

- Automatic mode (hook in place).
- Per-objective matching (needs M8.9's ordering question closed).
- TRAVEL destinations and a radius field in route data/schema.
- Per-character progress.
- Incorporating M8.7–M8.13 addenda into `M8_2_SCOPE.md`.
- Clipped window edge; "M8.7" labels in `MapPin.lua` comments (both pre-existing).

```text
M8.13 STATUS: IMPLEMENTED — 81/81 stub tests; real-client validation pending
```
